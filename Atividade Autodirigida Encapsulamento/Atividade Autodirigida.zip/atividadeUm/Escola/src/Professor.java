public class Professor extends Pessoa {
    private String disciplina;
    private String curso;
    
    // Constructors
    public Professor(String nome, String sobrenome, String endereco, Integer telefone, String email,
            String dataNascimento, String disciplina, String curso) {
        super(nome, sobrenome, endereco, telefone, email, dataNascimento);
        this.disciplina = disciplina;
        this.curso = curso;
    }

    // Getters
    public String getDisciplina() {
        return disciplina;
    }
    public String getCurso() {
        return curso;
    }
   
}
