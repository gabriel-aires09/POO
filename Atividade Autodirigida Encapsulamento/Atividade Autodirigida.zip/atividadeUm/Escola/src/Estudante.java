public class Estudante extends Pessoa {
    private Integer matricula;
    private String turno;
    private String cursosMatriculados;
    
    
    public Estudante(String nome, String sobrenome, String endereco, Integer telefone, String email,
            String dataNascimento, Integer matricula, String turno, String cursosMatriculados) {
        super(nome, sobrenome, endereco, telefone, email, dataNascimento);
        this.matricula = matricula;
        this.turno = turno;
        this.cursosMatriculados = cursosMatriculados;
    }


    // Getters
    public Integer getMatricula() {
        return matricula;
    }

    public String getTurno() {
        return turno;
    }

    public String getCursosMatriculados() {
        return cursosMatriculados;
    }

}
