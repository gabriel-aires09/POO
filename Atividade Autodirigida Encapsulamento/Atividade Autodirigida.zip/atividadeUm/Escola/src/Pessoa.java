public class Pessoa {
    private String nome;
    private String sobrenome;
    private String endereco;
    private Integer telefone;
    private String email;
    private String dataNascimento;
    

    // Constructors
    public Pessoa(String nome, String sobrenome, String endereco, Integer telefone, String email,
            String dataNascimento) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.email = email;
        this.dataNascimento = dataNascimento;
    }

    // Getters
    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public String getEndereco() {
        return endereco;
    }

    public Integer getTelefone() {
        return telefone;
    }

    public String getEmail() {
        return email;
    }

    public String getDataNascimento() {
        return dataNascimento;
    } 
}
