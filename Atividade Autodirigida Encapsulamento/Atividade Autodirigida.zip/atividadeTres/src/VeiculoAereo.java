public class VeiculoAereo extends Veiculo {
    private String tipoDeAsa;
    private Integer numeroDeMotores;
    
    public VeiculoAereo(String marca, String modelo, Integer anoDeFabricacao, String tipoDeAsa,
            Integer numeroDeMotores) {
        super(marca, modelo, anoDeFabricacao);
        this.tipoDeAsa = tipoDeAsa;
        this.numeroDeMotores = numeroDeMotores;
    }

    public String getTipoDeAsa() {
        return tipoDeAsa;
    }

    public Integer getNumeroDeMotores() {
        return numeroDeMotores;
    }
  
}
