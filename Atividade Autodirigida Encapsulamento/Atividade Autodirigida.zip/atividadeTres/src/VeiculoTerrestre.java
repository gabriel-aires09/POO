public class VeiculoTerrestre extends Veiculo {
    private Integer numeroDeRodas;
    private String tipoDeCombustivel;
    
    public VeiculoTerrestre(String marca, String modelo, Integer anoDeFabricacao, Integer numeroDeRodas,
            String tipoDeCombustivel) {
        super(marca, modelo, anoDeFabricacao);
        this.numeroDeRodas = numeroDeRodas;
        this.tipoDeCombustivel = tipoDeCombustivel;
    }

    public Integer getNumeroDeRodas() {
        return numeroDeRodas;
    }

    public String getTipoDeCombustivel() {
        return tipoDeCombustivel;
    }
 
}
