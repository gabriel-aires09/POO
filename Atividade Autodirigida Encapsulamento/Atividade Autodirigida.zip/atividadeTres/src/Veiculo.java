public class Veiculo {
    public String marca;
    public String modelo;
    public Integer anoDeFabricacao;
    
    // Constructor
    public Veiculo(String marca, String modelo, Integer anoDeFabricacao) {
        this.marca = marca;
        this.modelo = modelo;
        this.anoDeFabricacao = anoDeFabricacao;
    }

    // Getters
    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public Integer getAnoDeFabricacao() {
        return anoDeFabricacao;
    }
}
