public class VeiculoAquatico extends Veiculo {
    private String tipoDeMotor;
    private Boolean temHelice;
    
    public VeiculoAquatico(String marca, String modelo, Integer anoDeFabricacao, String tipoDeMotor,
            Boolean temHelice) {
        super(marca, modelo, anoDeFabricacao);
        this.tipoDeMotor = tipoDeMotor;
        this.temHelice = temHelice;
    }

    public String getTipoDeMotor() {
        return tipoDeMotor;
    }

    public Boolean getTemHelice() {
        return temHelice;
    }
}
