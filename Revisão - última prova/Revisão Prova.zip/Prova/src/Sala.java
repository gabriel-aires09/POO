public class Sala {
    private Integer numero;
    private String bloco;
    
    public Sala(Integer numero, String bloco) {
        this.numero = numero;
        this.bloco = bloco;
    }

    public Integer getNumero() {
        return numero;
    }

    public String getBloco() {
        return bloco;
    }

    
    
    
}
