public class Turma {
    private String periodo; // Exemplo: 2023/2

    public String getPeriodo() {
        return periodo;
    }

    
}
