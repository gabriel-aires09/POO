public class Smartphone extends Produtos {
    public Smartphone(String marca, String modelo, Integer numeroSerie, double preco) {
        super(marca, modelo, numeroSerie, preco);
    }

}
