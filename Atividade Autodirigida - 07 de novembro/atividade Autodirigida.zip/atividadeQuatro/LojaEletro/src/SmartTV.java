public class SmartTV extends Produtos {
    public SmartTV(String marca, String modelo, Integer numeroSerie, double preco) {
        super(marca, modelo, numeroSerie, preco);
    }


}
