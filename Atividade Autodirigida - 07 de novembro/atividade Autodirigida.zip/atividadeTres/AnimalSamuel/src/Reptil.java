public class Reptil extends Animal {
    public Reptil(String nome, Integer idade, double tamanho, String dieta, String habitat) {
        super(nome, idade, tamanho, dieta, habitat);
    }

    private String corPele;


    public String getCorPele() {
        return corPele;
    }




    
}
