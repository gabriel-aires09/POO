public class Ave extends Animal {
    public Ave(String nome, Integer idade, double tamanho, String dieta, String habitat) {
        super(nome, idade, tamanho, dieta, habitat);
    }

    private String corAsa;
   
    public String getCorAsa() {
        return corAsa;
    }

    
    
}
